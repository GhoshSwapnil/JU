console.log("Welcome to JU");

img1.onclick=function(){
	alert("hi");
}