import * as S from "./State/data.js"

// console.log(S.state0)
// console.log(S.state1)


//References
const stateSelectedReff= document.getElementById("selectedState");
const distSelectedReff= document.getElementById("selectedDist")

const districtCont= document.getElementById("card2");

distSelectedReff.style.display= "none";
districtCont.style.display= "none";

//global variables
let flag= false;
let state;
let stateNo;

stateSelectedReff.addEventListener("change",() =>{
     state=  (stateSelectedReff.options[stateSelectedReff.selectedIndex].text);
     stateNo=  (stateSelectedReff.options[stateSelectedReff.selectedIndex].value);

    if ( stateNo == "noState"){
        flag= false;
        alert("Please Select A Valid State !");
        return;
    }
    flag= true;

    console.log(" State --  "+ state+ " State no --  "+ stateNo.substring(5));
    
    switch(stateNo.substring(5)){

        case "0":{
           let str= `<option value="noDist" default>None</option>`;

           for ( let i=0; i< S.state0.length; i++){
                str+=`<option value="dist${i}">${S.state0[i]}</option>`
           }
           distSelectedReff.style.display= "block";
           districtCont.style.display= "block";

          // alert(str);
          
           distSelectedReff.innerHTML= str;
        }
        break;

        case "1":{
             let str= `<option value="noDist" default>None</option>`;

             for ( let i=0; i< S.state1.length; i++){
                str+=`<option value="dist${i}">${S.state1[i]}</option>`
             }

             distSelectedReff.style.display= "block";
             districtCont.style.display= "block";

             // alert(str);

             distSelectedReff.innerHTML= str;
        }
        break;
        // we can add more state here 
    }
});

distSelectedReff.addEventListener("change", () =>{
     if ( flag ){
                 
        const outputReff= document.getElementById("outputBox");

        
        let distNo= distSelectedReff.options[distSelectedReff.selectedIndex].value;
        
        if ( distNo == "noDist"){
           alert("Please Select a Valid District !")
           return;
        }

        let distNoF= distNo.substring(4);
        let dist= distSelectedReff.options[distSelectedReff.selectedIndex].text;
                    
       //  alert("Hi, stateNo -- "+stateNo + "  distNo -- "+ distNo);

       if ( stateNo.substring(5) == "0" && distNoF == "0"){
         outputReff.innerHTML= `<h3>${state}, ${dist}</h3>
                                 <p>Sed posuere dui iaculis accumsan lacinia. Vestibulum a massa sit amet arcu efficitur tincidunt a vitae neque. Sed consequat, turpis sit amet consequat egestas, ante magna dictum sapien, ac fermentum ex sem non leo. Vestibulum risus nisi, accumsan sed nisi eu, eleifend imperdiet est. Vivamus eleifend, turpis non vulputate fermentum, risus libero pretium elit, in mattis augue dui sed ante. Nam mattis non augue vitae elementum. Suspendisse id metus varius, sagittis augue id, tincidunt magna. Nulla ac ex dictum, volutpat tortor et, venenatis lorem. Vivamus vel neque eget magna suscipit pharetra. Praesent facilisis lorem sit amet lorem commodo, ac aliquet quam tincidunt. Aliquam erat volutpat. Suspendisse tincidunt viverra tellus vel ultricies. Vivamus quis mauris vel arcu convallis porta. Pellentesque cursus dignissim quam, et volutpat massa pulvinar nec.</p>`;
       }
       else if ( stateNo.substring(5) == "0" && distNoF == "1"){
            outputReff.innerHTML= `<h3>${state}, ${dist}</h3>
                                    <p>Duis ac venenatis eros. Vestibulum at metus in nulla dictum tempus. Vestibulum in odio accumsan, ullamcorper orci ac, eleifend quam. Donec risus enim, maximus sit amet pharetra nec, vulputate id diam. Cras est mauris, iaculis ut varius et, dictum eget diam. Nunc at congue purus, vel volutpat felis. Duis pulvinar dignissim hendrerit. Quisque fermentum dui nec est vulputate malesuada. Mauris sodales sapien id eros tempus porta. Donec vel hendrerit est. Nullam sem diam, feugiat at ornare vel, varius ut nisi. Maecenas sodales nec libero id elementum. Aliquam at lobortis tellus. Vestibulum nec luctus neque, id ullamcorper nibh. Nunc sed euismod arcu. Nullam consectetur, eros vitae laoreet pulvinar, est metus gravida ligula, ac volutpat massa augue a leo.</p>`;
        }

        else if ( stateNo.substring(5) == "0" && distNoF == "2"){
        outputReff.innerHTML= `<h3>${state}, ${dist}</h3>
                                           <p>Quisque interdum ligula nec nulla efficitur, non vestibulum sem consectetur. Etiam maximus tincidunt aliquet. Etiam tincidunt est a quam imperdiet euismod. Nullam sodales bibendum posuere. Maecenas magna tortor, pretium et gravida id, porttitor et enim. Quisque ultricies nisl non nisl condimentum cursus. Aenean eu erat justo. Integer a enim ligula. Sed dapibus dapibus porttitor. Praesent ut iaculis eros, quis faucibus neque. Donec aliquet eros eros, et volutpat nunc sodales non. Phasellus erat lectus, ornare eget lacus non, viverra iaculis tellus. Nunc consequat, justo vel viverra volutpat, velit erat tempus arcu, ac malesuada lectus ipsum a nunc. Mauris vitae tortor vehicula, posuere magna pulvinar, tempus velit. Aenean scelerisque nulla nec diam fringilla vehicula.</p>`;
        }
     //  we can add here more detailsfor every district belonging to particular state
     }
});