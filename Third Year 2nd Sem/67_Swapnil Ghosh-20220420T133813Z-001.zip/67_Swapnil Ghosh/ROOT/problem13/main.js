const inputReff= document.getElementById("num1");
const outputReff= document.getElementById("output");

function findFact(){
    let n= inputReff.value;

    if ( n < 0){
        alert("Please Enter a Positive Number.");
        return;
    }
    const workerObj= new Worker("worker.js");

    workerObj.postMessage(n);//Sending message

    workerObj.onmessage= function(e){//Receiving message 
         outputReff.innerHTML= `Factorial of ${n} is ${e.data}`;
   }
}