import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.*;


import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@MultipartConfig
public class UploadServlet extends HttpServlet {
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, InterruptedException {
        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) {
            
            Part part = request.getPart("file");
            String fileName = part.getSubmittedFileName();//getting the file name
            //out.println("File Name -> "+fileName+"<br>");
            
            
        
            //String path= getServletContext().getRealPath("/"+"files"+File.separator+fileName);//getting the absolute path of "files" folder, in which we will store files
            String path= "D:/webDevelopment/College/Assignment 2/problem8/webApp/files/" + fileName;
            System.out.println(path);
            
            InputStream fips = part.getInputStream();
            boolean isUpoaded= uploadFile(fips, path);
            
            if(isUpoaded){
//            	out.println("<br>files folder path -> "+ path);
//              out.println("<br><h1>Uploaded Successfully !!</h1>");
            	out.println("<h1> E X A M </h1>");
                insert(response, path);
          
            }else{
                out.println("<br><h1>Upload Unsuccessful !!<h1>");
            }
        }
    }
	
	public boolean uploadFile(InputStream fips, String path){
        boolean isUpoaded= false;
        try{
            byte[] byt= new byte[fips.available()];
            fips.read(byt);
            
            FileOutputStream fops = new FileOutputStream(path);
            fops.write(byt);
            
            fops.flush();
            fops.close();
            
            isUpoaded= true;
            
        }catch(Exception e){
           System.out.print("<br><h1>Some error while Saving the File"+e+"<h1>");
        }
        
        return isUpoaded;
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try { 
			processRequest(request, response);
		} catch (Exception e) {
			System.out.println("Error Occured -> "+e);
		}
	}
	
	protected void insert(HttpServletResponse response, String path) throws IOException {
		PrintWriter out = response.getWriter();
		BufferedReader br= new BufferedReader(new FileReader(new File(path)));
		
		
		Connection con= null;
		Statement st= null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
	        con= DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","Shya.1957");
			st= con.createStatement();
		
			
		    int lineCount= 0;
		    int Qcount= 1;//Question Count
		    int Acount= 0;//Answer Count 
		    String line= br.readLine();
		    
		    out.println("<form action=\"check.jsp\">");
		    String currentQuestionHTMLSoFar= "";
		    String currentQuerySoFar= "INSERT INTO EXAM(Q_No, QUESTION, A, B, C, D, ANS)  VALUES(";
		    
	        while (line != null) {
	    	
	    	   if ( lineCount > 5) {
	    		  lineCount= lineCount%6;
	    	   }
	    	   if ( lineCount == 0) {
	    		   
	    		   currentQuestionHTMLSoFar= "<p>Question "+Qcount+"&#x2192;<br>"+line+"</p>";
	    		   
	    		   currentQuerySoFar+=Qcount+",\""+line+"\",";
	    		   
	    	   }
	    	   else if (lineCount > 0 && lineCount < 5 ) {
	    		  
	    		   char option= (char)(Acount+65);
	    		   Acount+=1;
	    		   
	    		   currentQuestionHTMLSoFar+="<input type=\"radio\" name=\""+Qcount+"Q"+"\" value=\""+option+"\">";
	    		   currentQuestionHTMLSoFar+="<span>"+option+")"+line+"</span><br>";
	    		   
	    		   
	    		   currentQuerySoFar+="\""+line+"\",";
	    	   }
	    	   else if ( lineCount == 5) {
	    		   
	    		   out.println(currentQuestionHTMLSoFar+"<br><br>");
	    		   Qcount+=1;
	    		   Acount= 0;
	    		   currentQuestionHTMLSoFar="";
	    		   
	    		   currentQuerySoFar+="\""+line+"\")";
	    		   System.out.println(currentQuerySoFar);
	    		   st.executeUpdate(currentQuerySoFar);//current query generated so far 
	    		   
	    		   currentQuerySoFar= "INSERT INTO EXAM(Q_No, QUESTION, A, B, C, D, ANS)  VALUES(";//for next Question insert 
	    	   }
	    	   
	    	   lineCount+=1;
	    	   line= br.readLine();
	       }
	        out.println(" <input type=\"submit\" value=\"Submit\"> </form>");
		}
		catch(Exception e) {
			System.out.println("Some error while querying, "+ e);
		}
		finally {
			try {
				con.close();
			}
			catch(Exception e) {
				System.out.println("Some error while closing the connection, "+ e);
			}
		}
		         
	}
}
