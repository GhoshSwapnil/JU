import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class Password //Java Beans Mandatory for JSF
{
    private String username;
    private String oldPass;
    private String newPass;

    public void setUsername(String username)
    {
        this.username = username;
    }

    public void setOldPass(String oldPass)
    {
        this.oldPass = oldPass;
    }

    public void setNewPass(String newPass)
    {
        this.newPass = newPass;
    }

    public String getUsername()
    {
        return this.username;
    }

    public String getOldPass()
    {
        return this.oldPass;
    }

    public String getNewPass()
    {
        return this.newPass;
    }

    public String change()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","Shya.1957");

            String query = "SELECT password from login where user_name=?";
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

          
            if (rs.next()) {
                if (rs.getString("user_password").equals(oldPass) != true)  //Not valid Old Password
                    return "password";
            }
            else
                return "username";//Invalid old Password
            
            String update= "UPDATE login SET user_password=? WHERE user_name=?";

            PreparedStatement ps1 = con.prepareStatement(update);
            ps1.setString(1, newPass);
            ps1.setString(2, username);
            ps1.executeUpdate();

            ps.close();
            ps1.close();
            con.close();

            return "success";//Redirect to Success Page 
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return "database";//Redirect to Invalid Database Page 
    }

}