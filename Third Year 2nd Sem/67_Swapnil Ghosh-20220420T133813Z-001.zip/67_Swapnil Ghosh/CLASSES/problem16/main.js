var valid_username = false;
var valid_old_password = false;
var valid_new_password1 = false;
var valid_new_password2 = false;


function validate_fields()
{
    if(valid_username && valid_old_password && valid_new_password1 && valid_new_password2)
    {
        window.document.getElementById("form1:submit_click").disabled = false;
        return;
    }

    window.document.getElementById("form1:submit_click").disabled= true;
}


function validate_username()
{
    document.getElementById("error_name").innerHTML= '';
    const name_pattern = /^\w{1,10}$/;
    const name = document.getElementById("form1:username").value;

    if (name.length > 10)
    {
        document.getElementById("error_name").innerHTML= 'Maximum 10 characters permitted';
        valid_username = false;
        return;
    }

    var res = name_pattern.test(name);

    if (res)
    {
        valid_username = true;
        return;
    }

    document.getElementById("error_name").innerHTML= 'Login name can only have alphanumeric characters and underscore';
    valid_username = false;
    return;
}



function validate_old_password()
{
    document.getElementById('error_old').innerHTML = '';
    const password_pattern = /^(?=.*[0-9])(?=\S+$).{5,10}$/;

    const password = document.getElementById('form1:oldPass').value;
    
    if (password.length > 10)
    {
        document.getElementById("error_old").innerHTML= 'Maximum 10 characters permitted';
        valid_old_password = false;
        return;
    }

    if (password.length < 5)
    {
        document.getElementById("error_old").innerHTML= 'Minimum 5 characters necessary';
        valid_old_password = false;
        return;
    }

    const res = password_pattern.test(password);

    if(res)
    {
        valid_old_password = true;
        return;
    }

    document.getElementById("error_old").innerHTML= 'Must contain a digit';
    valid_old_password = false;
    return;
}


function validate_new_password()
{
    document.getElementById('error_new1').innerHTML = '';
    const password_pattern = /^(?=.*[0-9])(?=\S+$).{5,10}$/;

    const password = document.getElementById('form1:newPass').value;
    
    if (password.length > 10)
    {
        document.getElementById("error_new1").innerHTML= 'Maximum 10 characters permitted';
        valid_new_password1 = false;
        return;
    }

    if (password.length < 5)
    {
        document.getElementById("error_new1").innerHTML= 'Minimum 5 characters necessary';
        valid_new_password1 = false;
        return;
    }

    const res = password_pattern.test(password);

    if(res)
    {
        valid_new_password1 = true;
        return;
    }

    document.getElementById("error_new1").innerHTML= 'Must contain a digit';
    valid_new_password1 = false;
    return;
}


function check_equal()
{
    var second_pass = document.getElementById("form1:newPass1");

    if(second_pass.value == document.getElementById("form1:newPass").value)
    {
        document.getElementById('error_new2').innerHTML = '';
        valid_new_password2 = true;
        return;
    }

    document.getElementById('error_new2').innerHTML = 'Does not match with the other password';
    valid_new_password2 = false;
    return;
}


function change_password_visibility()
{
    if (document.getElementById('form1:oldPass').getAttribute('type') == 'password')
    {
        document.getElementById('form1:oldPass').setAttribute('type', 'text');
        document.getElementById('form1:newPass').setAttribute('type', 'text');
        document.getElementById('form1:newPass1').setAttribute('type', 'text');
        document.getElementById('button1').innerHTML='Hide passwords';
        return;
    }

    document.getElementById('form1:oldPass').setAttribute('type', 'password');
    document.getElementById('form1:newPass').setAttribute('type', 'password');
    document.getElementById('form1:newPass1').setAttribute('type', 'password');
    document.getElementById('button1').innerHTML='Show passwords';
}