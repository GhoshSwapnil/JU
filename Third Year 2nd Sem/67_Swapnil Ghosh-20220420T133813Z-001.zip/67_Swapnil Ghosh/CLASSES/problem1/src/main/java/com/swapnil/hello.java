package com.swapnil;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class hello extends HttpServlet{

		 public void service(HttpServletRequest req, HttpServletResponse res) throws IOException   {
			 PrintWriter out= res.getWriter();
			 out.print("Hello World");
		 }
}
